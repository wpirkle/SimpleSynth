var struct_x_hold_fader =
[
    [ "XHoldFader", "struct_x_hold_fader.html#a6c65900e2e2369d37d855253435f4977", null ],
    [ "XHoldFader", "struct_x_hold_fader.html#a28c6c75035f62654677864a2cdeb657a", null ],
    [ "processInputChannels", "struct_x_hold_fader.html#a43a9da0d1410a2ad001ec5f0bdd02c77", null ],
    [ "reset", "struct_x_hold_fader.html#ab7f522c9435a8e8fc0a88526126e21b2", null ],
    [ "setPureXfade", "struct_x_hold_fader.html#a5aecc8c6cb6b4def6ed3f1cc57a0cbe3", null ],
    [ "setSampleRate", "struct_x_hold_fader.html#a8d4f4f32e8c5ec6e52a1c5609ec9faae", null ],
    [ "setSourceHoldTime_mSec", "struct_x_hold_fader.html#a8c3a462efcc27129df2547afe2222a4d", null ],
    [ "setXFadeTime_mSec", "struct_x_hold_fader.html#a89a707fc62bcdf1fdcc4d7800ef24495", null ],
    [ "updateHoldTime", "struct_x_hold_fader.html#a8a1af460077b08fc3f02578a7d8fe793", null ],
    [ "updateXFadeTime", "struct_x_hold_fader.html#a80b9fdaa93245c14d1390a1ab6cee15d", null ],
    [ "holdTime_Counter", "struct_x_hold_fader.html#ac67466444d40a95e12bea8ef538d9c51", null ],
    [ "holdTime_mSec", "struct_x_hold_fader.html#ae83ac11d589701e837cfde941b5d3b3f", null ],
    [ "holdTime_Samples", "struct_x_hold_fader.html#a0658f64be4811e759b0304265adc8012", null ],
    [ "pureCrossfade", "struct_x_hold_fader.html#af29465146aa6c982b0601ed4498b5c0e", null ],
    [ "sampleRate", "struct_x_hold_fader.html#ae27fc9d3d70d13d27383a279eebfcde8", null ],
    [ "xfadeTime_Counter", "struct_x_hold_fader.html#a0e5c1658f8ccb3c0181973085ce93a1d", null ],
    [ "xfadeTime_mSec", "struct_x_hold_fader.html#a576fb8d9165e3dad771f26ebdc962281", null ],
    [ "xfadeTime_Samples", "struct_x_hold_fader.html#a125bb39c60122191ed8db684acb6c210", null ]
];