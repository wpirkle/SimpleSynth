var struct_moog_filter_parameters =
[
    [ "MoogFilterParameters", "struct_moog_filter_parameters.html#abf5b9c664dccbea91ca6021411d482a9", null ],
    [ "operator=", "struct_moog_filter_parameters.html#aa4ac9bfac0e10ee1e845d2ad1d4e9e6d", null ],
    [ "enableGainComp", "struct_moog_filter_parameters.html#a6750a0bc103291657c05600a88a77b2e", null ],
    [ "enableNLP", "struct_moog_filter_parameters.html#a27fbab41de5455f1a617fa193a89d24f", null ],
    [ "fc", "struct_moog_filter_parameters.html#afe62463724747f10b2d096a5ab80f3a3", null ],
    [ "filterAlgorithm", "struct_moog_filter_parameters.html#aaac85480b1c63cfbeee2fdc7d8276f56", null ],
    [ "filterOutputGain_dB", "struct_moog_filter_parameters.html#a789df10184516960dade470fc3077ee6", null ],
    [ "Q", "struct_moog_filter_parameters.html#ab6acf9426ff3bdfee2362a5adbf68fbb", null ]
];