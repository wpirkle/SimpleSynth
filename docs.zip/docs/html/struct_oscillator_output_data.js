var struct_oscillator_output_data =
[
    [ "OscillatorOutputData", "struct_oscillator_output_data.html#af0418bf74370fa6659b6788bedc4608a", null ],
    [ "clear", "struct_oscillator_output_data.html#aa726c945b42d37713a69065a2d21b73a", null ],
    [ "outputs", "struct_oscillator_output_data.html#a45a8cb40e1f779ee28d8fe5c4b2ee9e4", null ]
];