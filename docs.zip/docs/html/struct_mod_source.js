var struct_mod_source =
[
    [ "ModSource", "struct_mod_source.html#af1ecee3c3b747a289e5ce39038946ed8", null ],
    [ "clear", "struct_mod_source.html#a514a578b426c17ec9ac1658c27343da8", null ],
    [ "operator=", "struct_mod_source.html#a070549024b1ba61c49b74ba42bf294ea", null ],
    [ "masterIntensity", "struct_mod_source.html#aeb1aabf157d126079e2b74c8a1eb53fb", null ]
];