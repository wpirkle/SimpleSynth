var class_i_wave_sample =
[
    [ "createWaveSamples", "class_i_wave_sample.html#af5d4c77b8582d60aeb93c730a8b65063", null ],
    [ "getLoopMode", "class_i_wave_sample.html#ac3fdd189b664474cbad33b8a13c56246", null ],
    [ "getWaveSampleCount", "class_i_wave_sample.html#a9d2b549aa0ee0a7d32f2ff9d2b789e87", null ],
    [ "selectWaveSample", "class_i_wave_sample.html#a2efa0615104e3160492f08e7cd264fbb", null ]
];