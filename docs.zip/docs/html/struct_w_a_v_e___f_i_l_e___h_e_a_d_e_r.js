var struct_w_a_v_e___f_i_l_e___h_e_a_d_e_r =
[
    [ "dwAvgBytesPerSec", "struct_w_a_v_e___f_i_l_e___h_e_a_d_e_r.html#a285ff2e927046163539c15118c687593", null ],
    [ "dwSamplesPerSec", "struct_w_a_v_e___f_i_l_e___h_e_a_d_e_r.html#aeacc80f1c0e21e03d545210ead37db14", null ],
    [ "wBitsPerSample", "struct_w_a_v_e___f_i_l_e___h_e_a_d_e_r.html#a6e484b589743cb24f3a266f9bcf1b7d6", null ],
    [ "wBlockAlign", "struct_w_a_v_e___f_i_l_e___h_e_a_d_e_r.html#ab8122c65a05b2a4b8b95785f37a640fe", null ],
    [ "wChannels", "struct_w_a_v_e___f_i_l_e___h_e_a_d_e_r.html#a1db35e33e0c09b5f2526925fd27d0eaa", null ],
    [ "wFormatTag", "struct_w_a_v_e___f_i_l_e___h_e_a_d_e_r.html#a6e05033f481c70a89cfd1d4b6f6f7df7", null ]
];