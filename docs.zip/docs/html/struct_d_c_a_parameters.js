var struct_d_c_a_parameters =
[
    [ "DCAParameters", "struct_d_c_a_parameters.html#a9a6b47c0a425b83bb5039996ca41ca1a", null ],
    [ "operator=", "struct_d_c_a_parameters.html#af0cea18d4b6d3e8a5010d6015569c49a", null ],
    [ "gain_dB", "struct_d_c_a_parameters.html#a40fc76b8ad924f3a6a681806df8e2f5d", null ],
    [ "mute", "struct_d_c_a_parameters.html#a58030dbce682760be8622505f424a83b", null ],
    [ "panValue", "struct_d_c_a_parameters.html#a568f36f829ff6ae04125002e67d8ea43", null ]
];