var class_d_c_a =
[
    [ "DCA", "class_d_c_a.html#a2bbbd1ad8b723898de787d10664093f5", null ],
    [ "~DCA", "class_d_c_a.html#ac4e33788b13d879d407c064ea5c0b393", null ],
    [ "canProcessAudioFrame", "class_d_c_a.html#acab7b80d22a64daa348cb1abb8d057bf", null ],
    [ "doNoteOff", "class_d_c_a.html#a6487852916945ef0869247ac4ff4de04", null ],
    [ "doNoteOn", "class_d_c_a.html#a5ea1083c2d88a82eda02175803ec783b", null ],
    [ "getModulators", "class_d_c_a.html#a86f7a531632d14d684dc8a4923c75d26", null ],
    [ "processAudioSample", "class_d_c_a.html#a91cc6e4d58243c742066ed3b3e579a06", null ],
    [ "processSynthAudio", "class_d_c_a.html#ab10221731a199755cf78eb21c6fb064c", null ],
    [ "reset", "class_d_c_a.html#a59ef0a1812b3add23ddaad1320e868bb", null ],
    [ "setModulators", "class_d_c_a.html#a0d7db9175331a3bd9d41b5dfe9e51ac5", null ],
    [ "update", "class_d_c_a.html#ac64f333783dd5051aadfd7c7f46934d3", null ],
    [ "gainRaw", "class_d_c_a.html#ad2a341161333f3c39371ca385a6d1522", null ],
    [ "midiInputData", "class_d_c_a.html#ab85be2d94c68dd189e00b06d917cb9a7", null ],
    [ "midiVelocityGain", "class_d_c_a.html#a5d8a0ef95d27ab337ed54242ceef918f", null ],
    [ "modulators", "class_d_c_a.html#ace0e4eb56235151978d82720d2115c21", null ],
    [ "noteOn", "class_d_c_a.html#a1e2342cbf60e15379b2470b3d187bc7c", null ],
    [ "panLeftGain", "class_d_c_a.html#abe93773221be5a88d8c0930319eff970", null ],
    [ "panRightGain", "class_d_c_a.html#a2aacfb76bf92f735439f0568069e9858", null ],
    [ "panValue", "class_d_c_a.html#a13e289bf43853c28c8a9057c5395c528", null ],
    [ "parameters", "class_d_c_a.html#a8ed888256d40ea1dd54b03b4903285a4", null ]
];