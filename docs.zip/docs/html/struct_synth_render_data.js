var struct_synth_render_data =
[
    [ "SynthRenderData", "struct_synth_render_data.html#a920039a0ae6c9b84a5939c2c9349a833", null ],
    [ "clear", "struct_synth_render_data.html#afec979a80357b10a576a9d78e3edeecb", null ],
    [ "channelCount", "struct_synth_render_data.html#adc602ce8e7d9c0db593f7e23a300484e", null ],
    [ "synthOutputs", "struct_synth_render_data.html#ae3b758dd1ecce5a032aae59251d3cdd4", null ]
];