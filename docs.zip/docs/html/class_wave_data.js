var class_wave_data =
[
    [ "WaveData", "class_wave_data.html#a48b151cdb225a911cae534d7586f9d67", null ],
    [ "~WaveData", "class_wave_data.html#a89023c5ea3efb669faf25491ebfc760f", null ],
    [ "readWaveFile", "class_wave_data.html#a136f17b3f73cbab5c30428d1d1b7bc60", null ],
    [ "m_bWaveLoaded", "class_wave_data.html#a978622e4f259126c954684bbd73ba824", null ],
    [ "m_pWaveBuffer", "class_wave_data.html#a764fd721fdd73b4cc8ef7aa3d368ed39", null ],
    [ "m_uLoopCount", "class_wave_data.html#a84e637661cc866f61dd51f81a353e870", null ],
    [ "m_uLoopEndIndex", "class_wave_data.html#ae60dc2afecd2d53b8a65c3959fb9f7a6", null ],
    [ "m_uLoopStartIndex", "class_wave_data.html#a9a609f2d89ab000f5945047a255976b8", null ],
    [ "m_uLoopType", "class_wave_data.html#a527edee4666d197f70174aa3b99f4ebf", null ],
    [ "m_uMIDINote", "class_wave_data.html#aa48090148cf523608b4de83bbe9df7d0", null ],
    [ "m_uMIDIPitchFraction", "class_wave_data.html#a7b8c271e0ee54c035e84a2dd806d0bb4", null ],
    [ "m_uNumChannels", "class_wave_data.html#a07cd7be06a6f2271eaa0356148e18ee3", null ],
    [ "m_uSampleCount", "class_wave_data.html#a4121cc6d19877d6bd1b0030617895c5c", null ],
    [ "m_uSampleRate", "class_wave_data.html#ac571ac99480ae6c1e6c68a6df2d80463", null ],
    [ "m_uSMPTEFormat", "class_wave_data.html#a8247920c07c70d157ff2e35bbe67c558", null ],
    [ "m_uSMPTEOffset", "class_wave_data.html#ab3bf8e83c4f0263a985d8af10a8875b4", null ]
];