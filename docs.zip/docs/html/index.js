var index =
[
    [ "Synth Oscillators", "pitched_oscillators.html", "pitched_oscillators" ],
    [ "Low Frequency Oscillators", "_l_f_os.html", null ]
];