var struct_x_fader =
[
    [ "XFader", "struct_x_fader.html#a704e2dce2fe1ab241d6252bd376f97fd", null ],
    [ "XFader", "struct_x_fader.html#a5e0355196e91a0451a615b0569a6ccc5", null ],
    [ "crossfade", "struct_x_fader.html#aaa11545d9c67dab4418fa50cad47471d", null ],
    [ "reset", "struct_x_fader.html#a9fe2810f02c4dd732fb7091e0f4db8a9", null ],
    [ "setXFadeTime", "struct_x_fader.html#ab6c4828b0cb0993d5e33506f9704846b", null ],
    [ "xfadeTime_Counter", "struct_x_fader.html#a88b5e7ed2cf845aaca2403206ec17eb1", null ],
    [ "xfadeTime_Samples", "struct_x_fader.html#a8ac80628562a7ad036b338a3362cdc8f", null ]
];