var struct_synth_processor_data =
[
    [ "SynthProcessorData", "struct_synth_processor_data.html#acb244e960ebac3c7f8071a7bd9503085", null ],
    [ "clear", "struct_synth_processor_data.html#ae01dafad1bf3fe1cc567fdf5f1770244", null ],
    [ "inputs", "struct_synth_processor_data.html#ad19871aba41383b9a328d55c57a71d2a", null ],
    [ "numInputChannels", "struct_synth_processor_data.html#ad464c5ca969986878daf83fc0865ee0b", null ],
    [ "numOutputChannels", "struct_synth_processor_data.html#aa475a12a82cddf37a47e9f494b972483", null ],
    [ "outputs", "struct_synth_processor_data.html#ae402a0332f989339ea14398056057267", null ]
];