var pitched_oscillators =
[
    [ "Wavetable Oscillators", "wavetable_oscillators.html", null ],
    [ "Morphing Wavetable Oscillators", "morphing_oscillators.html", null ]
];