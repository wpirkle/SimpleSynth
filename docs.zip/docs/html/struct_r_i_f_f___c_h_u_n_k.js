var struct_r_i_f_f___c_h_u_n_k =
[
    [ "dwLength", "struct_r_i_f_f___c_h_u_n_k.html#a5965f8a37130f5b36e36892ab022a90b", null ],
    [ "IdentifierString", "struct_r_i_f_f___c_h_u_n_k.html#af7a22b14a3e836d23ecad54deca8d9f3", null ]
];