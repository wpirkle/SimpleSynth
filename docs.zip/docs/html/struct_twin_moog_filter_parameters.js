var struct_twin_moog_filter_parameters =
[
    [ "TwinMoogFilterParameters", "struct_twin_moog_filter_parameters.html#ac043f15f0beb0c0010f8dccea678205f", null ],
    [ "operator=", "struct_twin_moog_filter_parameters.html#a5d5c5398914e73587fd7bb580090920c", null ],
    [ "enableGainComp", "struct_twin_moog_filter_parameters.html#a71551764f36ca21e3b79e9c295ecec6f", null ],
    [ "fc1", "struct_twin_moog_filter_parameters.html#a0ca3219dfed9cb56effd1338b6a9ded4", null ],
    [ "fc2", "struct_twin_moog_filter_parameters.html#a1e38b9af19d19aae4ff30cb77b68d095", null ],
    [ "filterConfiguration", "struct_twin_moog_filter_parameters.html#ae909f0d062b795d2444f1183cc4c6500", null ],
    [ "Q1", "struct_twin_moog_filter_parameters.html#a674fd41b88fb5052552a692a3495a4f9", null ],
    [ "Q2", "struct_twin_moog_filter_parameters.html#af8bbd3dacdfe979889cc47c972d7001f", null ]
];