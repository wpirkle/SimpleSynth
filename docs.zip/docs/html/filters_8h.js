var filters_8h =
[
    [ "__filters_h__", "filters_8h.html#a32a8f28d6443760c76019d43af8889c3", null ],
    [ "FILTER_TAP_1024", "filters_8h.html#ac7de84aec82061ee91aad17fddff2c8c", null ],
    [ "FILTER_TAP_128", "filters_8h.html#a9993ff3e018c7f54e6436d69623a7775", null ],
    [ "FILTER_TAP_256", "filters_8h.html#ab5a8e66a5b07c8fda5d307facb1ae95f", null ],
    [ "FILTER_TAP_512", "filters_8h.html#aeb915cfd1db7ff5b354acc9a57ef12be", null ]
];