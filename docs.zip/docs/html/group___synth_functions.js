var group___synth_functions =
[
    [ "pitchShiftTableLookup", "structpitch_shift_table_lookup.html", null ],
    [ "midiNoteNumberFromOscFrequency", "structmidi_note_number_from_osc_frequency.html", null ],
    [ "midiNoteNumberToOscFrequency", "structmidi_note_number_to_osc_frequency.html", null ]
];