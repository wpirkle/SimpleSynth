var struct_timer =
[
    [ "Timer", "struct_timer.html#a5f16e8da27d2a5a5242dead46de05d97", null ],
    [ "advanceTimer", "struct_timer.html#a43e0090d045fc576faaada5f7ce9235a", null ],
    [ "getTargetValueInSamples", "struct_timer.html#a3df05ce0b34d90fde962ad89db179929", null ],
    [ "getTick", "struct_timer.html#a05e27f7c6a4d6e0ce96e5aaaf11e43ea", null ],
    [ "resetTimer", "struct_timer.html#a820de3710c231c2f926937fe479d4d8e", null ],
    [ "setTargetValueInSamples", "struct_timer.html#a45d6f11bd674a30b3a4e67dc3768e710", null ],
    [ "timerExpired", "struct_timer.html#a2c4b282024c2472ba862806f6ef611a8", null ],
    [ "counter", "struct_timer.html#ae3d92e6e872adf904f94f20741bc09d4", null ],
    [ "targetValueInSamples", "struct_timer.html#a19f7a10745b07f1c75fb0907e809fd33", null ]
];