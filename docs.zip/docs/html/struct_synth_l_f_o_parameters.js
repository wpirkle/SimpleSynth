var struct_synth_l_f_o_parameters =
[
    [ "SynthLFOParameters", "struct_synth_l_f_o_parameters.html#af158d3ed7ab7a4b6bd648c2a75fb62d6", null ],
    [ "operator=", "struct_synth_l_f_o_parameters.html#a5fda954e9982b492fbed5a36a5afaf09", null ],
    [ "frequency_Hz", "struct_synth_l_f_o_parameters.html#a9d2133de2c0584c0e0fa7a69e7d8df68", null ],
    [ "mode", "struct_synth_l_f_o_parameters.html#a83dc065749b9e918f85b5c6b01bdab50", null ],
    [ "outputAmplitude", "struct_synth_l_f_o_parameters.html#aaeaf4fcc48cb487d6e7d51752e22d97d", null ],
    [ "waveform", "struct_synth_l_f_o_parameters.html#a3ab62599bd03bf6a054f647daefb9cdb", null ]
];