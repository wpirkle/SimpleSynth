var struct__wave__sample =
[
    [ "bPlaying", "struct__wave__sample.html#a68e41682feae8a96fee375db44542cb0", null ],
    [ "dwId", "struct__wave__sample.html#ac5a5f43f80df2f26c893887498e9d820", null ],
    [ "FXIndex", "struct__wave__sample.html#a8ab8b480739e1a7c3a216bf6d232b51d", null ],
    [ "Index", "struct__wave__sample.html#a844e0fa9ba65bfbdbbe5872c1526ce0e", null ],
    [ "pFXSampleData", "struct__wave__sample.html#a316faba1b50bcb39933c7d8ce83951dd", null ],
    [ "pNext", "struct__wave__sample.html#a52493f4cd8276839857fe97e9dd39bdc", null ],
    [ "pSampleData", "struct__wave__sample.html#aab590e1862707b22722fdbd3ad4321d3", null ],
    [ "Size", "struct__wave__sample.html#a4d3cbdc4c04aebb8010ea2c8cb757055", null ],
    [ "WaveFormatEx", "struct__wave__sample.html#af3e72273926a4006dc8c58e1d6474dd7", null ]
];