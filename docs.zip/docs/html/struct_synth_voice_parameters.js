var struct_synth_voice_parameters =
[
    [ "SynthVoiceParameters", "struct_synth_voice_parameters.html#a46afda68bb20a3f9bf36271222e40864", null ],
    [ "operator=", "struct_synth_voice_parameters.html#a7ae2db62564605f0036832cc8abc8e3d", null ],
    [ "ampEGParameters", "struct_synth_voice_parameters.html#aec8bc39248e20e97f4a7778e84e8adde", null ],
    [ "dcaParameters", "struct_synth_voice_parameters.html#a2679e489ed7c15270cd0f77476822c59", null ],
    [ "enablePortamento", "struct_synth_voice_parameters.html#acf194ee9430d0b3457467f473539637d", null ],
    [ "freeRunOscMode", "struct_synth_voice_parameters.html#aa3cc087f810c3b192519a371a89f18eb", null ],
    [ "legatoMode", "struct_synth_voice_parameters.html#a091a8c6d21a274a31ea62d39b662a23c", null ],
    [ "lfo1Parameters", "struct_synth_voice_parameters.html#a476e66a48b5d89072d953872a15ad155", null ],
    [ "osc1Parameters", "struct_synth_voice_parameters.html#a3bba88b8bd524ed24f0160bbf5c5ba06", null ],
    [ "portamentoTime_mSec", "struct_synth_voice_parameters.html#ae783121ac3be9250761747603eb6b437", null ],
    [ "voiceUnisonDetune_Cents", "struct_synth_voice_parameters.html#a7d2480cf4bfbb79240967077ff100749", null ]
];