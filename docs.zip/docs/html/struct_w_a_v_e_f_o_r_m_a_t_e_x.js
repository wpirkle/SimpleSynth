var struct_w_a_v_e_f_o_r_m_a_t_e_x =
[
    [ "cbSize", "struct_w_a_v_e_f_o_r_m_a_t_e_x.html#a85b1796522ad458f07eb702140e3e42d", null ],
    [ "nAvgBytesPerSec", "struct_w_a_v_e_f_o_r_m_a_t_e_x.html#a34af4a00a1c957d5a23bf9f37aca813a", null ],
    [ "nBlockAlign", "struct_w_a_v_e_f_o_r_m_a_t_e_x.html#a685d51a8ee3c640b8bae282b6fbae13d", null ],
    [ "nChannels", "struct_w_a_v_e_f_o_r_m_a_t_e_x.html#a6c4f4a01faa6ec779cb71742156c1b6a", null ],
    [ "nSamplesPerSec", "struct_w_a_v_e_f_o_r_m_a_t_e_x.html#af5cdd4578879bd41c95088bce6486bd3", null ],
    [ "wBitsPerSample", "struct_w_a_v_e_f_o_r_m_a_t_e_x.html#ae67454b36cd3a34be6a40700ee95de9f", null ],
    [ "wFormatTag", "struct_w_a_v_e_f_o_r_m_a_t_e_x.html#ae3e0a1f37326670332f9e5f31f296127", null ]
];