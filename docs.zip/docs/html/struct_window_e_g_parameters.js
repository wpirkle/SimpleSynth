var struct_window_e_g_parameters =
[
    [ "WindowEGParameters", "struct_window_e_g_parameters.html#ae34fc62353ed8aa8472843a0a9eca64a", null ],
    [ "operator=", "struct_window_e_g_parameters.html#ad71ce420072f94d71ef9ce48c886502e", null ],
    [ "offTime_mSec", "struct_window_e_g_parameters.html#a5358a6e5da01a40133a0c05a822afdea", null ],
    [ "widthInSamples", "struct_window_e_g_parameters.html#ab2875eb11b7203c85100fec5c94507ef", null ],
    [ "windowType", "struct_window_e_g_parameters.html#a96c00a410885ba4da694d4199887b32c", null ],
    [ "windowWidth_mSec", "struct_window_e_g_parameters.html#a6cd931a33131ff20e2bf6fa5128e8940", null ],
    [ "windowWidth_Samples", "struct_window_e_g_parameters.html#a583651f4fafce8fef846b10c1695850a", null ]
];