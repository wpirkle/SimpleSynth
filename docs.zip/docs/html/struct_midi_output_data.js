var struct_midi_output_data =
[
    [ "MidiOutputData", "struct_midi_output_data.html#a708b9152aef6e97d8234f57cf0b8f5bd", null ],
    [ "ccMIDIData", "struct_midi_output_data.html#a47cab9ded8bf3c9b3ce8899ff9015a51", null ],
    [ "globalMIDIData", "struct_midi_output_data.html#a40934f94165cb97c0516fa22cf4683ac", null ]
];