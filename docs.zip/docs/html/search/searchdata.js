var indexSectionsWithContent =
{
  0: "_abcdefghilmoprstuwxyz~",
  1: "_bcdeghimoprstuwxz",
  2: "f",
  3: "acdgiprstu~",
  4: "acdegimoprstuw",
  5: "m",
  6: "s",
  7: "lmswy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Modules",
  7: "Pages"
};

