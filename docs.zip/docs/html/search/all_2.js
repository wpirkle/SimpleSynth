var searchData=
[
  ['bipolarinttomidi14_5fbit',['bipolarIntToMIDI14_bit',['../structbipolar_int_to_m_i_d_i14__bit.html',1,'']]],
  ['boundintvalue',['boundIntValue',['../structbound_int_value.html',1,'']]],
  ['boundmidivaluebyte',['boundMIDIValueByte',['../structbound_m_i_d_i_value_byte.html',1,'']]],
  ['boundmidivaluedoublebyte',['boundMIDIValueDoubleByte',['../structbound_m_i_d_i_value_double_byte.html',1,'']]]
];
