var searchData=
[
  ['zvafilterex',['ZVAFilterEx',['../class_z_v_a_filter_ex.html',1,'']]]
];
