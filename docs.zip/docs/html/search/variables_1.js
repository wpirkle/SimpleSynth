var searchData=
[
  ['ccmididata',['ccMIDIData',['../struct_midi_input_data.html#a2612f59a7bd74a359b7c525587a50736',1,'MidiInputData::ccMIDIData()'],['../struct_midi_output_data.html#a47cab9ded8bf3c9b3ce8899ff9015a51',1,'MidiOutputData::ccMIDIData()']]]
];
