var searchData=
[
  ['synth_20oscillators',['Synth Oscillators',['../pitched_oscillators.html',1,'index']]]
];
