var searchData=
[
  ['morphing_20wavetable_20oscillators',['Morphing Wavetable Oscillators',['../morphing_oscillators.html',1,'pitchedOscillators']]]
];
