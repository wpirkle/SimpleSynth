var searchData=
[
  ['_5fwave_5fsample',['_wave_sample',['../struct__wave__sample.html',1,'']]]
];
