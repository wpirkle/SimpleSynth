var searchData=
[
  ['your_5fsynth_5fname',['YOUR_SYNTH_NAME',['../index.html',1,'']]]
];
