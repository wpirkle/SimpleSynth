var searchData=
[
  ['updategranularity',['updateGranularity',['../class_synth_voice.html#a3f1457ee680315bafe1e390ecc9b20a2',1,'SynthVoice']]]
];
