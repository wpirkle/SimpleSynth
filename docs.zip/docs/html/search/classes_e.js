var searchData=
[
  ['unipolardoubletomidi14_5fbit',['unipolarDoubleToMIDI14_bit',['../structunipolar_double_to_m_i_d_i14__bit.html',1,'']]],
  ['unipolartomidi14_5fbit',['unipolarToMIDI14_bit',['../structunipolar_to_m_i_d_i14__bit.html',1,'']]],
  ['uwavedata',['UWaveData',['../union_u_wave_data.html',1,'']]]
];
