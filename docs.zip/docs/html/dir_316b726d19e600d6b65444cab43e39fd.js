var dir_316b726d19e600d6b65444cab43e39fd =
[
    [ "analogsaw.h", "analogsaw_8h_source.html", null ],
    [ "dca_eg.h", "dca__eg_8h_source.html", null ],
    [ "filters.h", "filters_8h.html", "filters_8h" ],
    [ "synthcore.h", "synthcore_8h_source.html", null ],
    [ "synthdefs.h", "synthdefs_8h_source.html", null ],
    [ "synthlfo.h", "synthlfo_8h_source.html", null ],
    [ "synthoscillator.h", "synthoscillator_8h_source.html", null ],
    [ "trace.h", "trace_8h_source.html", null ],
    [ "vafilters.h", "vafilters_8h_source.html", null ],
    [ "wavedata.h", "wavedata_8h_source.html", null ],
    [ "wavetableoscillator.h", "wavetableoscillator_8h_source.html", null ],
    [ "window_eg.h", "window__eg_8h_source.html", null ]
];