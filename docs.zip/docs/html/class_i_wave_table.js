var class_i_wave_table =
[
    [ "getTableLength", "class_i_wave_table.html#a8b28923fe7fe32e7bd0f8a949e4e68e3", null ],
    [ "resetWaveTables", "class_i_wave_table.html#a2ec8793891a4eb1c7b3ee6a547330f67", null ],
    [ "selectTable", "class_i_wave_table.html#a150b9a7d36e0bc9af136d1caf61b0142", null ]
];