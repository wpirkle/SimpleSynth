var union_u_wave_data =
[
    [ "d", "union_u_wave_data.html#a8f3cc4a61138047013f1dd6df68aa0f1", null ],
    [ "f", "union_u_wave_data.html#a3c07026860cfe0f93ea18087c076526a", null ],
    [ "n", "union_u_wave_data.html#adc298beee3bc45149aa8877a89a6185a", null ],
    [ "u", "union_u_wave_data.html#aa2afcf44763a11bb614d9fc9eedf7072", null ],
    [ "u64", "union_u_wave_data.html#aefb6771d6a13a08de700807a224e93ed", null ]
];