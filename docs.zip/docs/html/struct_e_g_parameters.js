var struct_e_g_parameters =
[
    [ "EGParameters", "struct_e_g_parameters.html#aeb8175ef71da84a1fb9533dd60b6f468", null ],
    [ "operator=", "struct_e_g_parameters.html#af3025827f80682066c30084966f4674b", null ],
    [ "attackTime_mSec", "struct_e_g_parameters.html#a592a1c0afc9bb9ce0ed53977d97c8960", null ],
    [ "decayTime_mSec", "struct_e_g_parameters.html#a2a9eecea95c322cc2a8ff466cecad905", null ],
    [ "delayTime_mSec", "struct_e_g_parameters.html#a4d607d820e6bd16596e237194a85f394", null ],
    [ "egContourType", "struct_e_g_parameters.html#adf1aef63092510ca835569837763ce12", null ],
    [ "egMode", "struct_e_g_parameters.html#a666d76bdeb9bddd97275e1563a0c3946", null ],
    [ "holdTime_mSec", "struct_e_g_parameters.html#a4a77e7a8c498442faf503624b05c764e", null ],
    [ "legatoMode", "struct_e_g_parameters.html#afaa37a1b3f99416bbe0a0384513d62c8", null ],
    [ "noteNumberToDecayScaling", "struct_e_g_parameters.html#acaa771f134fe7a976c241a8e24eb396b", null ],
    [ "offTime_mSec", "struct_e_g_parameters.html#a3735073ac93d548730303baf161047cd", null ],
    [ "releaseTime_mSec", "struct_e_g_parameters.html#a10747760b7250aefc569ee5a13fb07c2", null ],
    [ "resetToZero", "struct_e_g_parameters.html#a00839e3ce86016bc66f71fec05f3f97f", null ],
    [ "sustainLevel", "struct_e_g_parameters.html#a9289638d5cbb4d71c067edf88e2e47dc", null ],
    [ "velocityToAttackScaling", "struct_e_g_parameters.html#a30f4161e93a208f19ea53f57ee23c43f", null ]
];