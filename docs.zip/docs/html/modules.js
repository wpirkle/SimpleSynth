var modules =
[
    [ "SynthClasses", "group___synth_classes.html", "group___synth_classes" ],
    [ "SynthDefs", "group___synth_defs.html", "group___synth_defs" ],
    [ "SynthFunctions", "group___synth_functions.html", "group___synth_functions" ],
    [ "SynthStructures", "group___synth_structures.html", "group___synth_structures" ]
];