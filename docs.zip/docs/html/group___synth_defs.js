var group___synth_defs =
[
    [ "boundMIDIValueByte", "structbound_m_i_d_i_value_byte.html", null ],
    [ "boundMIDIValueDoubleByte", "structbound_m_i_d_i_value_double_byte.html", null ],
    [ "boundIntValue", "structbound_int_value.html", null ],
    [ "mapDoubleValue", "structmap_double_value.html", null ],
    [ "mapIntValue", "structmap_int_value.html", null ],
    [ "mapUintValue", "structmap_uint_value.html", null ],
    [ "mapDoubleToUINT", "structmap_double_to_u_i_n_t.html", null ],
    [ "mapUINTToDouble", "structmap_u_i_n_t_to_double.html", null ],
    [ "midi14_bitToBipolar", "structmidi14__bit_to_bipolar.html", null ],
    [ "midi14_bitToUnipolarInt", "structmidi14__bit_to_unipolar_int.html", null ],
    [ "midi14_bitToUnipolarDouble", "structmidi14__bit_to_unipolar_double.html", null ],
    [ "midi14_bitToDouble", "structmidi14__bit_to_double.html", null ],
    [ "unipolarToMIDI14_bit", "structunipolar_to_m_i_d_i14__bit.html", null ],
    [ "bipolarIntToMIDI14_bit", "structbipolar_int_to_m_i_d_i14__bit.html", null ],
    [ "unipolarDoubleToMIDI14_bit", "structunipolar_double_to_m_i_d_i14__bit.html", null ],
    [ "midiPitchBendToBipolar", "structmidi_pitch_bend_to_bipolar.html", null ]
];