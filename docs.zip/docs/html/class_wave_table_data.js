var class_wave_table_data =
[
    [ "WaveTableData", "class_wave_table_data.html#ab244b15fd4f077366c07af1b8375af52", null ],
    [ "~WaveTableData", "class_wave_table_data.html#a35d2e8eb474ba0191d8c0ff4ea4acee3", null ],
    [ "destroyWaveTables", "class_wave_table_data.html#a37dd4d037f4ccfc0284f034a81f01da7", null ],
    [ "getTableIndex", "class_wave_table_data.html#a52fce39e6eb13bca7456a35f17b65bf3", null ],
    [ "getTableLength", "class_wave_table_data.html#aa7aaee090fb9e65489f8ebc3f157b7c8", null ],
    [ "resetWaveTables", "class_wave_table_data.html#a84b94e52f016e4ed5cb4dbd4c0431a91", null ],
    [ "selectTable", "class_wave_table_data.html#af609fdad1119b69cc27a89caa2220ec6", null ]
];