var struct_synth_osc_parameters =
[
    [ "SynthOscParameters", "struct_synth_osc_parameters.html#aae5e6db5148f997751fc251e56178e43", null ],
    [ "operator=", "struct_synth_osc_parameters.html#abe5763e33c29a701d9a5e1ad3976f48b", null ],
    [ "detuneCents", "struct_synth_osc_parameters.html#a5bc9d75071c25a69eda5acc2239644c4", null ],
    [ "detuneOctaves", "struct_synth_osc_parameters.html#a2c24c5a4543791d248eb787ce9a8195f", null ],
    [ "detuneSemitones", "struct_synth_osc_parameters.html#ace6057c9e1fb4cad9f3634f0ec7de91c", null ],
    [ "enableFreeRunMode", "struct_synth_osc_parameters.html#acc6fbbf7f0c48a3d91962aa8959d4026", null ],
    [ "enableHardSync", "struct_synth_osc_parameters.html#a2ac67338234e6e69ea810694155760d7", null ],
    [ "fmRatio", "struct_synth_osc_parameters.html#aa492901d88c49dc0dd1f1d1be6890f37", null ],
    [ "hardSyncRatio", "struct_synth_osc_parameters.html#a4124d92856b6f8e021fee71ee5fe1706", null ],
    [ "oscillatorShape", "struct_synth_osc_parameters.html#a6c02a8b5874909e452dcea7386b33997", null ],
    [ "oscillatorWaveform", "struct_synth_osc_parameters.html#af7669caadd7de450c0edf05d3f22a488", null ],
    [ "outputAmplitude", "struct_synth_osc_parameters.html#a6a882a2d5377da3e969ca374d607d09f", null ],
    [ "pulseWidth_Pct", "struct_synth_osc_parameters.html#af30c53848a2c97b3ffd67ccda825c827", null ],
    [ "unisonDetuneCents", "struct_synth_osc_parameters.html#a13a7f0e62db9e20b5a4df2184f3e00d4", null ]
];