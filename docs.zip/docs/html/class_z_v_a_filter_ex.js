var class_z_v_a_filter_ex =
[
    [ "ZVAFilterEx", "class_z_v_a_filter_ex.html#a3120d15f764b35eef29015c97c030bd7", null ],
    [ "~ZVAFilterEx", "class_z_v_a_filter_ex.html#ada5a25696d212f09766b36db8b25413a", null ],
    [ "getAlpha", "class_z_v_a_filter_ex.html#a77dffaaaaa1eb9e3c84dfaa816b818e5", null ],
    [ "getLittle_g", "class_z_v_a_filter_ex.html#afdca509a72fa900b1793aa960dd76084", null ],
    [ "getS0Port", "class_z_v_a_filter_ex.html#ac51cfa9a0474a208d23b7562cf949680", null ],
    [ "getS1Port", "class_z_v_a_filter_ex.html#aa5bd67b9ff94110ea3462a0bb2f9af6b", null ]
];