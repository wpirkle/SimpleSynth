var struct_midi_input_data =
[
    [ "MidiInputData", "struct_midi_input_data.html#affc22c49506e6132eeb1934543d57253", null ],
    [ "ccMIDIData", "struct_midi_input_data.html#a2612f59a7bd74a359b7c525587a50736", null ],
    [ "globalMIDIData", "struct_midi_input_data.html#a5e2bef11adee7d556fa6319252375aeb", null ]
];