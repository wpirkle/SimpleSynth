var class_i_synth_component =
[
    [ "initialize", "class_i_synth_component.html#aea6633f4c858388f1ccd7b9a12a8b3cc", null ],
    [ "processMIDIEvent", "class_i_synth_component.html#a66ebf52d4f3f57fe571a5e90ab12bf16", null ],
    [ "renderAudioOutput", "class_i_synth_component.html#a92036efec8c2ea651b705a90f1082ae3", null ],
    [ "reset", "class_i_synth_component.html#a2d5977cfc67a8d327c3980b3e01fb730", null ]
];